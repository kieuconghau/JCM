package jcm.entity;

public class LecturerAccountEntity extends AccountEntity {
}
