package jcm.entity;

public class QuestionEntity {

}
