package jcm.constant;

public enum ERequestType {
    GET,
    POST
}
