package jcm.entity;

public class QuestionBlankEntity  extends  QuestionEntity{
}
