package jcm.entity;

public class StudentAccountEntity extends AccountEntity {
}
