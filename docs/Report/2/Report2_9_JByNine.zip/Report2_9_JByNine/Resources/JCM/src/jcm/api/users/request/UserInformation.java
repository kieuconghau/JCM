package jcm.api.users.request;

import jcm.model.UserInformations;

public class UserInformation {
    public int id;
    public String email;
    public String user;
}

