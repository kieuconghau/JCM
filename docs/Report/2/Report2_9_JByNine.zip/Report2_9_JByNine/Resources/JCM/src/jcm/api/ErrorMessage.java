package jcm.api;

public class ErrorMessage {
    public String message;
    public int error_code;
}
