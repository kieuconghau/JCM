package jcm.entity;

public class AccountEntity {
}
