package jcm.api.users.request;

public class LoginAccount {
    protected String username;
    protected String password;
}
