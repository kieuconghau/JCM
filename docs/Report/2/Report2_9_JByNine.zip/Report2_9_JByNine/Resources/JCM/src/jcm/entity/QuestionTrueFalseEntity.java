package jcm.entity;

public class QuestionTrueFalseEntity  extends  QuestionEntity{
}
