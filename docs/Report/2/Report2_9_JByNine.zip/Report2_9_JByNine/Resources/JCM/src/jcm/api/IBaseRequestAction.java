package jcm.api;

public interface IBaseRequestAction {
    String getRequest();
    String  postRequest();
}
