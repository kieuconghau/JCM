package jcm.constant;

public enum EUserRole {
    ADMIN,
    LECTURER,
    STUDENT
}
